﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class FrmEnvioMensagem : Form
    {
        public FrmEnvioMensagem()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você apertou na label inteiro");
        }

        private void FrmEnvioMensagem_Load(object sender, EventArgs e)
        {
            MessageBox.Show("Bem vindo ao formulário de mensagem!");
        }

        private void txtInteiro_TextChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Alterei a txt inteiro");
        }

        private void lblDecimal_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você apertou na label decimal");
        }

        private void txtDecimal_TextChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Alterei a txt decimal");
        }

        private void lblTexto_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você apertou na label texto");
        }

        private void txtTexto_TextChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Alterei a txt texto");
        }

        private void lblBooleano_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você apertou na abel Booleano");
        }

        private void txtBooleano_TextChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Alterei a txt booleano");
        }

        private void btnMostrar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Cliquei no botão mostrar");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Cliquei no botão limpar");
        }
    }
}
