﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AtvRevisãoCalc
{
    public partial class frmCalculadora : Form
    {
        public frmCalculadora()
        {
            InitializeComponent();
        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            // Criar variáveis e capturar dados da tela
            float valor1 = float.Parse(txtNum1.Text);
            float valor2 = float.Parse(txtNum2.Text);
            float soma;

            //Processamento - operação
            soma = valor1 + valor2;

            // Saída
            MessageBox.Show("O resultado da soma é: " + soma);
        }

        private void btnSubtração_Click(object sender, EventArgs e)
        {
            float valor1 = float.Parse(txtNum1.Text);
            float valor2 = float.Parse(txtNum2.Text);
            float subtrair;

            subtrair = valor1 - valor2;
            MessageBox.Show("O resultado da subtração é: " + subtrair);
        }

        private void btnMultlipicação_Click(object sender, EventArgs e)
        {
            float valor1 = float.Parse(txtNum1.Text);
            float valor2 = float.Parse(txtNum2.Text);
            float multiplicar;

            multiplicar = valor1 * valor2;
            MessageBox.Show("o resultado da multliplicação é: " + multiplicar);

        }

        private void btnDivisão_Click(object sender, EventArgs e)
        {
            float valor1 = float.Parse(txtNum1.Text);
            float valor2 = float.Parse(txtNum2.Text);
            float divisao;

            divisao = valor1 / valor2;
            MessageBox.Show("O resultado da divisão é: " + divisao);
        }
    }
}
