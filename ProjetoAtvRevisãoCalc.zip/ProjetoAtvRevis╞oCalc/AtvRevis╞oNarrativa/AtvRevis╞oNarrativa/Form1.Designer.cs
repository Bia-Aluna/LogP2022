﻿namespace AtvRevisãoNarrativa
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtValorSer = new System.Windows.Forms.TextBox();
            this.lblValorASer = new System.Windows.Forms.Label();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.lblValorPago = new System.Windows.Forms.Label();
            this.txtValorPago = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // txtValorSer
            // 
            this.txtValorSer.Location = new System.Drawing.Point(293, 80);
            this.txtValorSer.Name = "txtValorSer";
            this.txtValorSer.Size = new System.Drawing.Size(114, 20);
            this.txtValorSer.TabIndex = 0;
            // 
            // lblValorASer
            // 
            this.lblValorASer.AutoSize = true;
            this.lblValorASer.Location = new System.Drawing.Point(290, 64);
            this.lblValorASer.Name = "lblValorASer";
            this.lblValorASer.Size = new System.Drawing.Size(125, 13);
            this.lblValorASer.TabIndex = 1;
            this.lblValorASer.Text = "Digite o valor a ser pago:";
            // 
            // btnCalcular
            // 
            this.btnCalcular.Location = new System.Drawing.Point(293, 192);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(114, 55);
            this.btnCalcular.TabIndex = 2;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // lblValorPago
            // 
            this.lblValorPago.AutoSize = true;
            this.lblValorPago.Location = new System.Drawing.Point(298, 117);
            this.lblValorPago.Name = "lblValorPago";
            this.lblValorPago.Size = new System.Drawing.Size(99, 13);
            this.lblValorPago.TabIndex = 3;
            this.lblValorPago.Text = "Digite o valor pago:";
            // 
            // txtValorPago
            // 
            this.txtValorPago.Location = new System.Drawing.Point(297, 133);
            this.txtValorPago.Name = "txtValorPago";
            this.txtValorPago.Size = new System.Drawing.Size(110, 20);
            this.txtValorPago.TabIndex = 4;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtValorPago);
            this.Controls.Add(this.lblValorPago);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.lblValorASer);
            this.Controls.Add(this.txtValorSer);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtValorSer;
        private System.Windows.Forms.Label lblValorASer;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Label lblValorPago;
        private System.Windows.Forms.TextBox txtValorPago;
    }
}

