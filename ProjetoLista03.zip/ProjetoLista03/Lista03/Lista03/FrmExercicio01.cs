﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lista03
{
    public partial class FrmExercicio01 : Form
    {
        public FrmExercicio01()
        {
            InitializeComponent();
        }



        private void btnSoma_Click(object sender, EventArgs e)
        {
            float N1 = float.Parse(txtNum1.Text);
            float N3 = float.Parse(txtNum3.Text);
            float soma;

            soma = N1 + N3;
            lblResultSoma.Text = "Soma é igual a: " + soma;


        }

        private void btnMedia_Click(object sender, EventArgs e)
        {
            float N1 = float.Parse(txtNum1.Text);
            float N2 = float.Parse(txtNum2.Text);
            float N3 = float.Parse(txtNum3.Text);
            float media;

            media = (N1 + N2 + N3) / 3;
            lblResultMedia.Text = "Sua média é: " + media;

        }

        private void btnPorce_Click(object sender, EventArgs e)
        {
            float N1 = float.Parse(txtNum1.Text);
            float N2 = float.Parse(txtNum2.Text);
            float N3 = float.Parse(txtNum3.Text);
            float total, porcN1, porcN2, porcN3;

            total = N1 + N2 + N3;
            porcN1 = N1 / total;
            porcN2 = N2 / total;
            porcN3 = N3 / total;

            //   lblResultPorc.Text = "Num1 é: " + porcN1 + " % -" Num2 é " + porcN2 + "% -" + "Num3 é " + porcN3 + "% .";
        }
    }
}
