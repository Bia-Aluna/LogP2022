﻿namespace Lista03
{
    partial class FrmExercicio01
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNum1 = new System.Windows.Forms.Label();
            this.lblNum3 = new System.Windows.Forms.Label();
            this.lblNum2 = new System.Windows.Forms.Label();
            this.txtNum1 = new System.Windows.Forms.TextBox();
            this.txtNum2 = new System.Windows.Forms.TextBox();
            this.txtNum3 = new System.Windows.Forms.TextBox();
            this.btnSoma = new System.Windows.Forms.Button();
            this.btnMedia = new System.Windows.Forms.Button();
            this.btnPorce = new System.Windows.Forms.Button();
            this.lblEx1 = new System.Windows.Forms.Label();
            this.lblResultSoma = new System.Windows.Forms.Label();
            this.lblResultMedia = new System.Windows.Forms.Label();
            this.lblResultPorc = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblNum1
            // 
            this.lblNum1.AutoSize = true;
            this.lblNum1.Location = new System.Drawing.Point(194, 172);
            this.lblNum1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNum1.Name = "lblNum1";
            this.lblNum1.Size = new System.Drawing.Size(43, 17);
            this.lblNum1.TabIndex = 0;
            this.lblNum1.Text = "Num1";
            // 
            // lblNum3
            // 
            this.lblNum3.AutoSize = true;
            this.lblNum3.Location = new System.Drawing.Point(537, 172);
            this.lblNum3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNum3.Name = "lblNum3";
            this.lblNum3.Size = new System.Drawing.Size(43, 17);
            this.lblNum3.TabIndex = 1;
            this.lblNum3.Text = "Num3";
            // 
            // lblNum2
            // 
            this.lblNum2.AutoSize = true;
            this.lblNum2.Location = new System.Drawing.Point(351, 172);
            this.lblNum2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNum2.Name = "lblNum2";
            this.lblNum2.Size = new System.Drawing.Size(43, 17);
            this.lblNum2.TabIndex = 2;
            this.lblNum2.Text = "Num2";
            // 
            // txtNum1
            // 
            this.txtNum1.Location = new System.Drawing.Point(177, 194);
            this.txtNum1.Margin = new System.Windows.Forms.Padding(4);
            this.txtNum1.Name = "txtNum1";
            this.txtNum1.Size = new System.Drawing.Size(116, 23);
            this.txtNum1.TabIndex = 3;
            // 
            // txtNum2
            // 
            this.txtNum2.Location = new System.Drawing.Point(343, 194);
            this.txtNum2.Margin = new System.Windows.Forms.Padding(4);
            this.txtNum2.Name = "txtNum2";
            this.txtNum2.Size = new System.Drawing.Size(116, 23);
            this.txtNum2.TabIndex = 4;
            // 
            // txtNum3
            // 
            this.txtNum3.Location = new System.Drawing.Point(526, 194);
            this.txtNum3.Margin = new System.Windows.Forms.Padding(4);
            this.txtNum3.Name = "txtNum3";
            this.txtNum3.Size = new System.Drawing.Size(116, 23);
            this.txtNum3.TabIndex = 5;
            // 
            // btnSoma
            // 
            this.btnSoma.Location = new System.Drawing.Point(177, 267);
            this.btnSoma.Name = "btnSoma";
            this.btnSoma.Size = new System.Drawing.Size(75, 23);
            this.btnSoma.TabIndex = 6;
            this.btnSoma.Text = "Soma";
            this.btnSoma.UseVisualStyleBackColor = true;
            this.btnSoma.Click += new System.EventHandler(this.btnSoma_Click);
            // 
            // btnMedia
            // 
            this.btnMedia.Location = new System.Drawing.Point(343, 276);
            this.btnMedia.Name = "btnMedia";
            this.btnMedia.Size = new System.Drawing.Size(75, 23);
            this.btnMedia.TabIndex = 7;
            this.btnMedia.Text = "Média";
            this.btnMedia.UseVisualStyleBackColor = true;
            this.btnMedia.Click += new System.EventHandler(this.btnMedia_Click);
            // 
            // btnPorce
            // 
            this.btnPorce.Location = new System.Drawing.Point(519, 267);
            this.btnPorce.Name = "btnPorce";
            this.btnPorce.Size = new System.Drawing.Size(105, 32);
            this.btnPorce.TabIndex = 8;
            this.btnPorce.Text = "Porcentagem ";
            this.btnPorce.UseVisualStyleBackColor = true;
            this.btnPorce.Click += new System.EventHandler(this.btnPorce_Click);
            // 
            // lblEx1
            // 
            this.lblEx1.AutoSize = true;
            this.lblEx1.Location = new System.Drawing.Point(22, 25);
            this.lblEx1.Name = "lblEx1";
            this.lblEx1.Size = new System.Drawing.Size(73, 17);
            this.lblEx1.TabIndex = 9;
            this.lblEx1.Text = "Exercício01";
            // 
            // lblResultSoma
            // 
            this.lblResultSoma.AutoSize = true;
            this.lblResultSoma.Location = new System.Drawing.Point(226, 343);
            this.lblResultSoma.Name = "lblResultSoma";
            this.lblResultSoma.Size = new System.Drawing.Size(103, 17);
            this.lblResultSoma.TabIndex = 10;
            this.lblResultSoma.Text = "Resultado Soma";
            // 
            // lblResultMedia
            // 
            this.lblResultMedia.AutoSize = true;
            this.lblResultMedia.Location = new System.Drawing.Point(226, 377);
            this.lblResultMedia.Name = "lblResultMedia";
            this.lblResultMedia.Size = new System.Drawing.Size(107, 17);
            this.lblResultMedia.TabIndex = 11;
            this.lblResultMedia.Text = "Resultado Média";
            // 
            // lblResultPorc
            // 
            this.lblResultPorc.AutoSize = true;
            this.lblResultPorc.Location = new System.Drawing.Point(226, 408);
            this.lblResultPorc.Name = "lblResultPorc";
            this.lblResultPorc.Size = new System.Drawing.Size(147, 17);
            this.lblResultPorc.TabIndex = 12;
            this.lblResultPorc.Text = "Resultado Porcentagem";
            // 
            // FrmExercicio01
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(849, 475);
            this.Controls.Add(this.lblResultPorc);
            this.Controls.Add(this.lblResultMedia);
            this.Controls.Add(this.lblResultSoma);
            this.Controls.Add(this.lblEx1);
            this.Controls.Add(this.btnPorce);
            this.Controls.Add(this.btnMedia);
            this.Controls.Add(this.btnSoma);
            this.Controls.Add(this.txtNum3);
            this.Controls.Add(this.txtNum2);
            this.Controls.Add(this.txtNum1);
            this.Controls.Add(this.lblNum2);
            this.Controls.Add(this.lblNum3);
            this.Controls.Add(this.lblNum1);
            this.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FrmExercicio01";
            this.Text = "Exercício01";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNum1;
        private System.Windows.Forms.Label lblNum3;
        private System.Windows.Forms.Label lblNum2;
        private System.Windows.Forms.TextBox txtNum1;
        private System.Windows.Forms.TextBox txtNum2;
        private System.Windows.Forms.TextBox txtNum3;
        private System.Windows.Forms.Button btnSoma;
        private System.Windows.Forms.Button btnMedia;
        private System.Windows.Forms.Button btnPorce;
        private System.Windows.Forms.Label lblEx1;
        private System.Windows.Forms.Label lblResultSoma;
        private System.Windows.Forms.Label lblResultMedia;
        private System.Windows.Forms.Label lblResultPorc;
    }
}

