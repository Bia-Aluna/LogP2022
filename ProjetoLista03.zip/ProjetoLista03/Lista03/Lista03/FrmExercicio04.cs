﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lista03
{
    public partial class FrmExercicio04 : Form
    {
        public FrmExercicio04()
        {
            InitializeComponent();
        }

        private void btnArea_Click(object sender, EventArgs e)
        {
            float VA = float.Parse(txtAlt.Text);
            float VB = float.Parse(txtBase.Text);
            float area;

            area = VA * VB;

            lblResult.Text = "O valor da área do quadrado é:" + area;
        }
    }
}
