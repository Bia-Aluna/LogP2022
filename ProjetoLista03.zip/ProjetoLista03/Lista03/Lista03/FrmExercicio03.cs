﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lista03
{
    public partial class FrmExercicio03 : Form
    {
        public FrmExercicio03()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            //Calculo Do prato
            float Peso = float.Parse(txtPeso.Text);
            float resultado;

            resultado = Peso * 34;

            //Mostra na tela
            lblPeso.Text = "O preço da sua refeição é: " + resultado; 
        }
    }
}
