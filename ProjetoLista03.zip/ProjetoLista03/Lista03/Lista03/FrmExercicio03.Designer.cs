﻿namespace Lista03
{
    partial class FrmExercicio03
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblPeso = new System.Windows.Forms.Label();
            this.txtPeso = new System.Windows.Forms.TextBox();
            this.lblResultado = new System.Windows.Forms.Label();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.pnlTopo = new System.Windows.Forms.Panel();
            this.lblEx03 = new System.Windows.Forms.Label();
            this.pnlBase = new System.Windows.Forms.Panel();
            this.pnlTopo.SuspendLayout();
            this.pnlBase.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblPeso
            // 
            this.lblPeso.AutoSize = true;
            this.lblPeso.Location = new System.Drawing.Point(167, 110);
            this.lblPeso.Name = "lblPeso";
            this.lblPeso.Size = new System.Drawing.Size(128, 13);
            this.lblPeso.TabIndex = 0;
            this.lblPeso.Text = "Peso da refeição (em kg):";
            // 
            // txtPeso
            // 
            this.txtPeso.Location = new System.Drawing.Point(170, 144);
            this.txtPeso.Name = "txtPeso";
            this.txtPeso.Size = new System.Drawing.Size(142, 20);
            this.txtPeso.TabIndex = 1;
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.Location = new System.Drawing.Point(349, 18);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(55, 13);
            this.lblResultado.TabIndex = 2;
            this.lblResultado.Text = "Resultado";
            // 
            // btnCalcular
            // 
            this.btnCalcular.Location = new System.Drawing.Point(307, 200);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(147, 42);
            this.btnCalcular.TabIndex = 3;
            this.btnCalcular.Text = "Calcular Preço";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // pnlTopo
            // 
            this.pnlTopo.BackColor = System.Drawing.Color.PaleGreen;
            this.pnlTopo.Controls.Add(this.lblEx03);
            this.pnlTopo.Location = new System.Drawing.Point(11, 10);
            this.pnlTopo.Name = "pnlTopo";
            this.pnlTopo.Size = new System.Drawing.Size(770, 63);
            this.pnlTopo.TabIndex = 4;
            // 
            // lblEx03
            // 
            this.lblEx03.AutoSize = true;
            this.lblEx03.Location = new System.Drawing.Point(90, 28);
            this.lblEx03.Name = "lblEx03";
            this.lblEx03.Size = new System.Drawing.Size(65, 13);
            this.lblEx03.TabIndex = 0;
            this.lblEx03.Text = "Exercicio 03";
            // 
            // pnlBase
            // 
            this.pnlBase.BackColor = System.Drawing.Color.LightSeaGreen;
            this.pnlBase.Controls.Add(this.lblResultado);
            this.pnlBase.Location = new System.Drawing.Point(10, 380);
            this.pnlBase.Name = "pnlBase";
            this.pnlBase.Size = new System.Drawing.Size(788, 65);
            this.pnlBase.TabIndex = 5;
            // 
            // FrmExercicio03
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pnlBase);
            this.Controls.Add(this.pnlTopo);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.txtPeso);
            this.Controls.Add(this.lblPeso);
            this.Name = "FrmExercicio03";
            this.Text = "FrmExercicio03";
            this.pnlTopo.ResumeLayout(false);
            this.pnlTopo.PerformLayout();
            this.pnlBase.ResumeLayout(false);
            this.pnlBase.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblPeso;
        private System.Windows.Forms.TextBox txtPeso;
        private System.Windows.Forms.Label lblResultado;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Panel pnlTopo;
        private System.Windows.Forms.Label lblEx03;
        private System.Windows.Forms.Panel pnlBase;
    }
}